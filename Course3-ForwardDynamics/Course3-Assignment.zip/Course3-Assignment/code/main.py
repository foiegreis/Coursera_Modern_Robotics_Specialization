from simulation import UR5Simulation

ur5 = UR5Simulation()
ur5.simulation1()
ur5.simulation2()
